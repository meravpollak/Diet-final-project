import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class WelcomeMenu {
    public Stage stage;
    public Scene scene;
    public GridPane content;
    public GridPane rightMenu;
    public Label userName;
    public PatientDataAccessor PatientdataAccessor;
    public TableColumn<BirthDayObject,String> id_col;
    public TableColumn<BirthDayObject,String>firstName_col;
    public TableColumn<BirthDayObject,String> lastName_col;
    public TableColumn<BirthDayObject,String> tel_col;
    public TableColumn <BirthDayObject,String> age_col;
    public TableView table;
    public BorderPane WelcomeBorderPane;
    public BorderPane login;

    public void lanch(Stage stageF, Scene sceneF, GridPane contentF, GridPane rightMenuF, String user, BorderPane log) throws SQLException, ClassNotFoundException {
        stage=stageF;
        scene=sceneF;
        content=contentF;
        login = log;
        rightMenu = rightMenuF;
        scene.getStylesheets().add(getClass().getResource("ViewStyle.css").toExternalForm());
        userName.setText(", "+user +" שלום ");
        PatientdataAccessor = new PatientDataAccessor("com.mysql.jdbc.Driver","jdbc:mysql://127.0.0.1:3306/diet","root","Dana1993!");
        ArrayList<Patient> listOfBirthdaysPatients = PatientdataAccessor.getBitrthday();
        bulidColumns();
        ObservableList<BirthDayObject> data = FXCollections.observableArrayList();
        for( Patient patient: listOfBirthdaysPatients) {
                BirthDayObject birthDayObject = new BirthDayObject(patient.getId(), patient.getFirstName(), patient.getLastName(), patient.getTel(), patient.getAge());
                data.add(birthDayObject);
                table.setItems(data);
        }
        PatientdataAccessor.shutdown();


    }

    public void bulidColumns()
    {
        id_col.setCellValueFactory(new PropertyValueFactory<BirthDayObject,String>("id"));
        firstName_col.setCellValueFactory(new PropertyValueFactory<BirthDayObject,String>("firstName"));
        lastName_col.setCellValueFactory(new PropertyValueFactory<BirthDayObject,String> ("lastName"));
        tel_col.setCellValueFactory(new PropertyValueFactory<BirthDayObject,String> ("tel"));
        age_col.setCellValueFactory(new PropertyValueFactory<BirthDayObject,String> ("age"));
    }
}
