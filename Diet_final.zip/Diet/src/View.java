
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;

public class View {

    @FXML
    private Stage stage;
    private Scene scene;
    public GridPane content;
    public MenuBar Menubar;
    public VBox Vbox;
    public ChoosePatient choosePatient;
    public GridPane rightMenu;
    public String userNameEntered;
    public Text mainLabel;
    public BorderPane login;
    public BorderPane vborder;

    // --------------------------------------------------

    public void lanchView(Stage stageFromLogin, Scene sceneFromLogin, String user, BorderPane log ) throws SQLException, ClassNotFoundException, IOException {
        stage=stageFromLogin;
        scene= sceneFromLogin;
        scene.getStylesheets().add(getClass().getResource("ViewStyle.css").toExternalForm());
        login = log;
        log.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
        login.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
        //shadow
        DropShadow shadow = new DropShadow();
        shadow.setBlurType(BlurType.GAUSSIAN);
        shadow.setColor(Color.WHITE);
        shadow.setHeight(5);
        shadow.setWidth(5);
        shadow.setRadius(5);
        shadow.setOffsetX(3.0);
        shadow.setOffsetY(2.0);
        shadow.setSpread(12);
        mainLabel.setEffect(shadow);
        //
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("WelcomeMenu.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        userNameEntered = user;
        WelcomeMenu welcomeMenu = fxmlLoader.getController();
        welcomeMenu.lanch(stage, scene, content,rightMenu, user, login);
    }
    //MainMenu
    public void mainmenu(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        scene.getStylesheets().add(getClass().getResource("ViewStyle.css").toExternalForm());
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("WelcomeMenu.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        WelcomeMenu welcomeMenu = fxmlLoader.getController();
        welcomeMenu.lanch(stage, scene, content,rightMenu, userNameEntered, login);
    }

    // --------------------------------------------------


    //Calendar
    public void Calander(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        System.out.println("  ");
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("CalendarWindow.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        CalendarWindow calendarWindow = fxmlLoader.getController();
        calendarWindow.lanch(stage, scene, content,rightMenu);
    }


    // -------------------------------------------------------------------
    // cards of patients
    public void ChooseAPatient(ActionEvent event) throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("ChoosePatient.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        ChoosePatient choosePatient = fxmlLoader.getController();
        choosePatient.lanchChoosePatient(stage, scene, content,rightMenu);

    }

    // cards of patients
    public void AddNewPatient(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("AddNewPatient.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        AddNewPatient addNewPatient = fxmlLoader.getController();
        addNewPatient.lanch(stage, scene, content,rightMenu);

    }

    // cards of patients
    public void DeletePatient(ActionEvent event) throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("DeletePatient.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        DeletePatient deletePatient = fxmlLoader.getController();
        deletePatient.lanch(stage, scene, content,rightMenu);

    }


    // -------------------------------------------------------------------

    //Reports
    public void MissingReports (ActionEvent event) throws IOException
    {
        Parent s = FXMLLoader.load(getClass().getResource("MissingReports.fxml"));
        content.getChildren().clear();
        content.getChildren().setAll(s);
    }

    //Reports
    public void TotalPayment(ActionEvent event) throws IOException
    {
        Parent s = FXMLLoader.load(getClass().getResource("TotalPayment.fxml"));
        content.getChildren().clear();
        content.getChildren().setAll(s);
    }

    //Reports
    public void OwnReports(ActionEvent event) throws IOException
    {
        Parent s = FXMLLoader.load(getClass().getResource("ReceivableReports.fxml"));
        content.getChildren().clear();
        content.getChildren().setAll(s);
    }

    // -------------------------------------------------------------------


    public void setResizeEvent(Scene scene) {
        scene.widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number oldSceneWidth, Number newSceneWidth) {

            }
        });
    }


    // -----------------------------------------------
    //Excel
    public void Food(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("FoodCard.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        FoodCard foodCard = fxmlLoader.getController();
        foodCard.lanch(stage, scene, content,rightMenu);
    }
    //Excel
    public void Deseas(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("DiseaseCard.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        DiseaseCard diseaseCard = fxmlLoader.getController();
        diseaseCard.lanch(stage, scene, content,rightMenu);
    }

    //Excel
    public void Therapy(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("TherapyCard.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        TherapyCard therapyCard = fxmlLoader.getController();
        therapyCard.lanch(stage, scene, content,rightMenu);
    }

    //Excel
    public void Diets(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("DietMenu.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        DietMenu dietMenu = fxmlLoader.getController();
        dietMenu.lanch(stage, scene, content,rightMenu);
    }

    //Excel
    public void Banks(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("BankCard.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        BankCard bankCard = fxmlLoader.getController();
        bankCard.lanch(stage, scene, content,rightMenu);
    }

    //Excel
    public void Cities(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("CitiesCard.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        CitiesCard citiesCard = fxmlLoader.getController();
        citiesCard.lanch(stage, scene, content,rightMenu);
    }

    //Excel
    public void Users(ActionEvent event) throws IOException, SQLException, ClassNotFoundException {
        FXMLLoader fxmlLoader = new FXMLLoader();
        Parent s = fxmlLoader.load(getClass().getResource("UsersCard.fxml").openStream());
        content.getChildren().clear();
        content.getChildren().addAll(s);
        UsersCard usersCard = fxmlLoader.getController();
        usersCard.lanch(stage, scene, content,rightMenu);
    }
    //endregion

}
